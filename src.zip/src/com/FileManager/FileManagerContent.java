
package com.filemanager;

import java.io.File;
import java.util.ArrayList;

import android.app.ActivityGroup;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.filemanager.local.FileManagerActivity;
import com.filemanager.oconnect.ConnectManager;


public class FileManagerContent extends ActivityGroup {
  public final static String ACTION_COPY = "com.FileManagerIntents.ACTION_COPY";
  public final static String ACTION_PASTE = "com.FileManagerIntents.ACTION_PASTE";
  public final static String ACTION_CUT = "com.FileManagerIntents.ACTION_CUT";
  public final static String ACTION_DELETE = "com.FileManagerIntents.ACTION_DELETE";
  public final static String ACTION_COPYFINISHED = "com.FileManagerIntents.ACTION_COPYFINISHED";
  public final static String ACTION_SHOWDOWNLOADPAGE = "com.FileManagerIntents.ACTION_SHOWDOWNLOADPAGE";
  public final static String ACTION_MOVEFINISHED = "com.FileManagerIntents.ACTION_MOVEFINISHED";
  public final static String ACTION_SELECTFILE = "com.FileManagerIntents.ACTION_SELECTFILE";
  public final static String ACTION_SELECTFOLDER = "com.FileManagerIntents.ACTION_SELECTFOLDER";
  // USB Host
  public final static String ACTION_USBDISKMOUNTED = "com.intent.action.USB_DISK_MOUNTED_NOTIFY";
  // USB Host End
  public final static String ACTION_MCUPLOADFROMEMMC = "com.FileManagerIntents.ACTION_MCUPLOADFROMEMMC";
  public final static String ACTION_MCUPLOADFROMSDCARD = "com.FileManagerIntents.ACTION_MCUPLOADFROMSDCARD";
  public final static String ACTION_MCSELECTUPLOADFILES = "com.FileManagerIntents.ACTION_MCSELECTUPLOADFILES";

  public final static String EXTRA_KEY_PASTEREASON = "PASTEREASON";
  public final static String EXTRA_VAL_REASONCOPY = "REASONCOPY";
  public final static String EXTRA_VAL_REASONCUT = "REASONCUT";

  public final static String EXTRA_KEY_COPYRESULT = "COPYRESULT";
  public final static String EXTRA_VAL_COPYSUCESSED = "COPYSUCESSED";
  public final static String EXTRA_VAL_COPYFAILED = "COPYFAILED";

  public final static String EXTRA_KEY_MOVERESULT = "MOVERESULT";
  public final static String EXTRA_VAL_MOVESUCCESS = "MOVESUCCESS";
  public final static String EXTRA_VAL_MOVEFAILED = "MOVEFAILED";
  public final static String EXTRA_VAL_MOVEMULTIPLEFAILED = "MOVEMULTIPLEFAILED";

  public final static String EXTRA_KEY_SOURCEFILENAME = "SOURCEFILENAME";
  public final static String EXTRA_KEY_DESTFILENAME = "DESTFILENAME";

  public static final String EXTRA_KEY_MC_UPLOAD_DIR = "MC_UPLOAD_DIR";

  static final public int MESSAGE_DELETE_FINISHED = 505;
  public static final int ARG_DELETE_FAILED = 0;
  public static final int ARG_FILES_DELETED = 1;
  public static final int ARG_FOLDER_DELETED = 2;
  public static final int ARG_FILE_DELETED = 3;
  public static final int ARG_DELETE_MULTIPLE_FAILED = 4;

  

  static private String mCurrentContent = null;
  static private Context mContext = null;
  static private ActivityGroup mInstance = null;
  private Handler mCurrentHandler;
  private Intent mPasteIntent = null;
  static private View mMoveNCancelview = null;
  private Button mPasteButton;
  private Button mCancelButton;
  private FrameLayout mContentPage;
  private View mFileChooserPanel;
  private Button mFileChooserCancelButton;
  private SambaExplorer mSmbExplorer;

  private static final String TAG = "FileManagerContent: ";

  @Override
  protected void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    initVar(this, this);

    mCurrentHandler = new Handler() {
      @Override
      public void handleMessage(Message msg) {
        FileManagerContent.this.handleMessage(msg);
      }
    };

    requestWindowFeature(Window.FEATURE_NO_TITLE);
    setContentView(R.layout.file_manager_content);
    mContentPage = (FrameLayout) findViewById(R.id.content);

    mMoveNCancelview = findViewById(R.id.move_n_cancel);
    mPasteButton = (Button) findViewById(R.id.paste_button);
    mPasteButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (mCurrentContent == null) {
          FileManagerApp.log(TAG + "mCurrentContent is null in pasteButton's onClick");
          cancelPaste();
          return;
        } else if (mCurrentContent.equals(FileManager.ID_LOCAL)) {
          mPasteIntent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else if (mCurrentContent.equals(FileManager.ID_REMOTE)) {
          mPasteIntent.setClass(mContext, com.filemanager.samba.RemoteFileManager.class);
        } else if (mCurrentContent.equals(FileManager.ID_EXTSDCARD)) {
          mPasteIntent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else if (mCurrentContent.equals(FileManager.ID_USB)) {
          mPasteIntent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else if (mCurrentContent.equals(FileManager.ID_CONNECT)) {
          mPasteIntent.setClass(mContext,
              com.filemanager.connect.ConnectManager.class);
        }
        getLocalActivityManager().startActivity(mCurrentContent, mPasteIntent);
        cancelPaste();
      }
    });
    mCancelButton = (Button) findViewById(R.id.cancel_button);
    mCancelButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        cancelPaste();
      }
    });
    showPasteButton();

    mFileChooserPanel = findViewById(R.id.file_chooser_panel);
    mFileChooserCancelButton = (Button) findViewById(R.id.file_chooser_cancel);
    mFileChooserCancelButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        finish();
      }
    });

    initContentPage();

    IntentFilter iFilt = new IntentFilter();
    iFilt.addAction(FileManagerContent.ACTION_COPYFINISHED);
    registerReceiver(mBroadCaseReveiver, iFilt);
  }

  private static void initVar(Context context, ActivityGroup instance) {
    mContext = context;
    mInstance = instance;
  }

  private void initContentPage() {
    Intent intent = getIntent();
    String intentAction = intent.getAction();
    String extraTitle = null;
    String extraStep = null;
    if (intentAction != null) {
      switch (FileManagerApp.getLaunchMode()) {
        case FileManagerApp.SELECT_FILE_MODE :
          extraTitle = intent.getStringExtra(FileManager.EXTRA_KEY_HOMESYNC_TITLE);
          extraStep = intent.getStringExtra(FileManager.EXTRA_KEY_HOMESYNC_STEP);
          if (extraTitle == null) {
            mFileChooserPanel.setVisibility(View.VISIBLE);
            findViewById(R.id.homesync_bar).setVisibility(View.GONE);
          } else {
            mFileChooserPanel.setVisibility(View.GONE);
            findViewById(R.id.homesync_bar).setVisibility(View.VISIBLE);
            ((TextView) findViewById(R.id.homesync_title)).setText(extraTitle);
            ((TextView) findViewById(R.id.homesync_step)).setText(extraStep);
          }
          break;
        case FileManagerApp.SELECT_FOLDER_MODE :
          extraTitle = intent.getStringExtra(FileManager.EXTRA_KEY_HOMESYNC_TITLE);
          extraStep = intent.getStringExtra(FileManager.EXTRA_KEY_HOMESYNC_STEP);
          if (extraTitle == null) {
            mFileChooserPanel.setVisibility(View.VISIBLE);
            findViewById(R.id.homesync_bar).setVisibility(View.GONE);
          } else {
            mFileChooserPanel.setVisibility(View.GONE);
            findViewById(R.id.homesync_bar).setVisibility(View.VISIBLE);
            ((TextView) findViewById(R.id.homesync_title)).setText(extraTitle);
            ((TextView) findViewById(R.id.homesync_step)).setText(extraStep);
          }
          break;
        case FileManagerApp.SELECT_GET_CONTENT :
          break;
        case FileManagerApp.NORMAL_MODE :
          mFileChooserPanel.setVisibility(View.GONE);
          break;
      }

      mCurrentContent = intent.getStringExtra(FileManager.EXTRA_KEY_CONTENT);
      Intent launchIntent = null;
      if (FileManager.ID_LOCAL.equals(mCurrentContent)) {
        launchIntent = new Intent(this, FileManagerActivity.class);
      } else if (FileManager.ID_REMOTE.equals(mCurrentContent)) {
        launchIntent = new Intent(this, RemoteFileManager.class);
      } else if (FileManager.ID_EXTSDCARD.equals(mCurrentContent)) {
        launchIntent = new Intent(this, FileManagerActivity.class);
      } else if (FileManager.ID_CONNECT.equals(mCurrentContent)) {
        launchIntent = new Intent(this, ConnectManager.class);
      } else if (FileManager.ID_USB.equals(mCurrentContent)) {
        launchIntent = new Intent(this, FileManagerActivity.class);
      } else {
        // didn't match any screen we know so exit
        finish();
        return;
      }
      launchIntent.setAction(FileManager.ACTION_RESTART_ACTIVITY);
      Window w = getLocalActivityManager().startActivity(mCurrentContent, launchIntent);
      showContentPage(w);
    }
  }

  private void showContentPage(Window w) {
    mContentPage.setVisibility(View.VISIBLE);
    View wd = w != null ? w.getDecorView() : null;
    if (wd != null) {
      wd.setVisibility(View.VISIBLE);
      wd.setFocusableInTouchMode(true);
      ((ViewGroup) wd).setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
      mContentPage.removeAllViews();
      mContentPage.addView(wd, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
          ViewGroup.LayoutParams.MATCH_PARENT));
      wd.requestFocus();
    } else {
      // error creating view, exit
      FileManagerApp.log(TAG + "Could not activate view, exiting");
      finish();
    }
  }

  static public Context getCurContext() {
    return mContext;
  }

  static public ActivityGroup getActivityGroup() {
    return mInstance;
  }

  @Override
  public void onDestroy() {
    unregisterReceiver(mBroadCaseReveiver);
    super.onDestroy();
  }

  @Override
  protected void onNewIntent(Intent intent) {
    String intentAction = intent.getAction();
    if (intentAction == null) {
      // no action needed, Intent is null
      FileManagerApp.log(TAG + "Received a null Intent in onNewIntent");
    } else if (intentAction.equals(ACTION_COPY)) {
      FileManagerApp.setPasteMode(FileManagerApp.COPY_MODE);
      FileManagerApp.setPasteFiles(intent.getStringArrayListExtra(EXTRA_KEY_SOURCEFILENAME));
      showPasteButton();
    } else if (intentAction.equals(ACTION_DELETE)) {
      delete(intent);
    } else if (intentAction.equals(ACTION_MOVEFINISHED)) {
      cancelPaste();
    } else if (intentAction.equals(ACTION_CUT)) {
      FileManagerApp.setPasteMode(FileManagerApp.MOVE_MODE);
      FileManagerApp.setPasteFiles(intent.getStringArrayListExtra(EXTRA_KEY_SOURCEFILENAME));
      showPasteButton();
    } else if (intentAction.equals(ACTION_SHOWDOWNLOADPAGE)) {
      FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_SDCARD, -1);
      Intent intent1 = new Intent(this, FileManagerActivity.class);
      intent1.setAction(ACTION_SHOWDOWNLOADPAGE);
      getLocalActivityManager().startActivity(FileManager.ID_LOCAL, intent1);
    } else if (intentAction.equals(ACTION_MCUPLOADFROMEMMC)) {
      FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_SDCARD, -1);
      intent.setClass(this, FileManagerActivity.class);
      Window w = getLocalActivityManager().startActivity(FileManager.ID_LOCAL, intent);
      showContentPage(w);
    } else if (intentAction.equals(ACTION_MCUPLOADFROMSDCARD)) {
      FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_ALT_SDCARD, -1);
      intent.setClass(this, FileManagerActivity.class);
      Window w = getLocalActivityManager().startActivity(FileManager.ID_EXTSDCARD, intent);
      showContentPage(w);
    }
  }

  private BroadcastReceiver mBroadCaseReveiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
      String intentAction = intent.getAction();
      if (intentAction == null) {
        // Intent is null, no action needed
        FileManagerApp.log(TAG + "Received a null Intent in BroadcastReceiver");
      } else if (intentAction.equals(ACTION_COPYFINISHED)) {
        if (EXTRA_VAL_COPYSUCESSED.equals(intent.getStringExtra(EXTRA_KEY_COPYRESULT))) {
          if (EXTRA_VAL_REASONCUT.equals(intent.getStringExtra(EXTRA_KEY_PASTEREASON))) {
            deleteAfterMove(intent);
            mPasteIntent = intent;  // save intent info for later use
            return;  // Move complete message to be sent out later
          }
        }
        String destination = findDestAct(intent);
        if (destination.equals(FileManager.ID_LOCAL)) {
          intent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else if (destination.equals(FileManager.ID_EXTSDCARD)) {
          intent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else if (destination.equals(FileManager.ID_REMOTE)) {
          intent.setClass(mContext, com.filemanager.samba.RemoteFileManager.class);
        } else if (destination.equals(FileManager.ID_CONNECT)) {
          intent.setClass(mContext, com.filemanager.connect.ConnectManager.class);
        } else if (destination.equals(FileManager.ID_USB)) {
          intent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else {
          // doesn't match any screen we know. do not process.
          return;
        }
        // Send copy finished or error message to destination now
        getLocalActivityManager().startActivity(destination, intent);
      }
    }
  };

  private void handleMessage(Message message) {
    switch (message.what) {
      case MESSAGE_DELETE_FINISHED :
        String destination = findDestAct(mPasteIntent);
        if (destination.equals(FileManager.ID_LOCAL)) {
          mPasteIntent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else if (destination.equals(FileManager.ID_EXTSDCARD)) {
          mPasteIntent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        }else if (destination.equals(FileManager.ID_USB)) {
          mPasteIntent.setClass(mContext, com.filemanager.local.FileManagerActivity.class);
        } else {
          // doesn't match any screen we know. do not process.
          return;
        }
        if (message.arg1 == ARG_FILES_DELETED || message.arg1 == ARG_FOLDER_DELETED ||
            message.arg1 == ARG_FILE_DELETED) {
          mPasteIntent.putExtra(EXTRA_KEY_MOVERESULT, EXTRA_VAL_MOVESUCCESS);
        } else if (message.arg1 == ARG_DELETE_MULTIPLE_FAILED) {
          mPasteIntent.putExtra(EXTRA_KEY_MOVERESULT, EXTRA_VAL_MOVEMULTIPLEFAILED);
        } else {
          mPasteIntent.putExtra(EXTRA_KEY_MOVERESULT, EXTRA_VAL_MOVEFAILED);
        }
        mPasteIntent.setAction(ACTION_MOVEFINISHED);
        getLocalActivityManager().startActivity(destination, mPasteIntent);
        mPasteIntent = null;
    }
  }

  public void delete(Intent intent) {
    // This will only be called from FileManagerActivity to delete files
    // unrelated to deleting after moving.
    ArrayList<String> deleteFiles =
        intent.getStringArrayListExtra(FileManagerContent.EXTRA_KEY_SOURCEFILENAME);
    deleteSelected(deleteFiles, FileManagerActivity.getCurrentHandler(), mCurrentContent);
  }

  public void deleteAfterMove(Intent intent) {
    String source = findSourceAct(intent);
    if (source.equals(FileManager.ID_LOCAL) || source.equals(FileManager.ID_EXTSDCARD) ||
        source.equals(FileManager.ID_USB) || source.equals(FileManager.ID_REMOTE)) {
      ArrayList<String> deleteFiles =
          intent.getStringArrayListExtra(FileManagerContent.EXTRA_KEY_SOURCEFILENAME);
      deleteSelected(deleteFiles, mCurrentHandler, source);
    } else {
      // No other screen supports move function
      FileManagerApp.log(TAG + "deleteAfterMove requested for invalid screen: " + source);
    }
  }

  private String findDestAct(Intent intent) {
    String destFileName = intent.getStringExtra(EXTRA_KEY_DESTFILENAME);
    if (destFileName != null) {
      if (destFileName.startsWith(FileManagerApp.SD_CARD_EXT_DIR)) {
        return FileManager.ID_EXTSDCARD;
      } else if (destFileName.startsWith(FileManagerApp.SD_CARD_DIR)) {
        return FileManager.ID_LOCAL;
      } else if (destFileName.startsWith(PREFIX_SMB_FILE)) {
        return FileManager.ID_REMOTE;
      } else if (destFileName.startsWith(PREFIX_CONNECT_FILE)) {
        return FileManager.ID_CONNECT;
      }
    }
    return FileManager.ID_USB;
  }

  private String findSourceAct(Intent intent) {
    ArrayList<String> sourceFiles = intent.getStringArrayListExtra(EXTRA_KEY_SOURCEFILENAME);
    try {
      String sourceFirst = sourceFiles.get(0);
      if (sourceFirst.startsWith(FileManagerApp.SD_CARD_EXT_DIR)) {
        return FileManager.ID_EXTSDCARD;
      } else if (sourceFirst.startsWith(FileManagerApp.SD_CARD_DIR)) {
        return FileManager.ID_LOCAL;
      } else if (sourceFirst.startsWith("smb://")) {
        return FileManager.ID_REMOTE;
      } else if (sourceFirst.startsWith(PREFIX_CONNECT_FILE)) {
        // TBD
        return FileManager.ID_CONNECT;
      }
    } catch (Exception e) {
      FileManagerApp.log(TAG + "exception in findSourceAct");
    }
    return FileManager.ID_USB;
  }

  private void showPasteButton() {
    Intent intent = new Intent(this, com.filemanager.FileManagerContent.class);
    if (FileManagerApp.getPasteMode() == FileManagerApp.COPY_MODE) {
      mPasteButton.setText(R.string.paste_button);
      intent.putExtra(EXTRA_KEY_PASTEREASON, EXTRA_VAL_REASONCOPY);
    } else if (FileManagerApp.getPasteMode() == FileManagerApp.MOVE_MODE) {
      mPasteButton.setText(R.string.move_button);
      intent.putExtra(EXTRA_KEY_PASTEREASON, EXTRA_VAL_REASONCUT);
    } else {
      // do not show paste button since intent is null
      FileManagerApp.log(TAG + "Not in Paste Mode in showPasteButton");
      mMoveNCancelview.setVisibility(View.GONE);
      return;
    }
    intent.setAction(ACTION_PASTE);
    intent.putStringArrayListExtra(FileManagerContent.EXTRA_KEY_SOURCEFILENAME,
        FileManagerApp.getPasteFiles());
    mPasteIntent = intent;
    mCancelButton.setText(R.string.cancel_button);
    mMoveNCancelview.setVisibility(View.VISIBLE);
  }

  private void cancelPaste() {
    mPasteIntent = null;
    mMoveNCancelview.setVisibility(View.GONE);
    FileManagerApp.setPasteMode(FileManagerApp.NO_PASTE);
    FileManagerApp.setPasteFiles(null);
  }

 public static void hidePasteButton() {
    mMoveNCancelview.setVisibility(View.GONE);
  }

 public static void displayPasteButton() {
    mMoveNCancelview.setVisibility(View.VISIBLE);
  }

  private void deleteSelected(ArrayList<String> deleteFiles, Handler handler, String fileLocation) {
    if ((deleteFiles != null) && (deleteFiles.size() > 0) && (fileLocation !=null)) {
      if (fileLocation.equals(FileManager.ID_REMOTE)) {
        mSmbExplorer = new SambaExplorer(null, mCurrentHandler, mInstance);
      }
      new DeleteThread(deleteFiles, handler, fileLocation).start();
    }
  }

  private class DeleteThread extends Thread {

    private ArrayList<String> mDeleteFiles;
    private Handler mParentHandler;
    private String mFileLocation;

    public DeleteThread(ArrayList<String> deleteFiles, Handler handler, String fileLocation) {
      super();
      mDeleteFiles = deleteFiles;
      mParentHandler = handler;
      mFileLocation = fileLocation;
    }

    @Override
    public void run() {
      boolean result = true;
      boolean folderDeleted = false;
      if (mDeleteFiles == null) {
        FileManagerApp.log(TAG + "DeleteThread mDeleteFiles is null, no operation to be done");
        return;
      }

      if (mFileLocation.equals(FileManager.ID_REMOTE)) {
        // Only used for delete after move use case for Samba
        result = mSmbExplorer.deletSmbFileNoBrowse(mDeleteFiles);
        mSmbExplorer = null;
      } else {
        // Internal Storage, SD Card, USB use case
        File file = null;
        for (String filename : mDeleteFiles) {
          file = new File(filename);
          if (file.exists()) {
            if (file.isDirectory()) {
              folderDeleted = true;
            }
            // checkFileToSetScanFlag(file);
            result = delete(file) && result;
          }
        }
        // Delete Files from Media store
        // new DeleteFileFromMediaStoreTask().execute(file);
      }

      if (result) {
        if (mDeleteFiles.size() > 1) {
          mParentHandler.obtainMessage(MESSAGE_DELETE_FINISHED, ARG_FILES_DELETED, 0).sendToTarget();
        } else if (folderDeleted) {
          mParentHandler.obtainMessage(MESSAGE_DELETE_FINISHED, ARG_FOLDER_DELETED, 0).sendToTarget();
        } else {
          mParentHandler.obtainMessage(MESSAGE_DELETE_FINISHED, ARG_FILE_DELETED, 0).sendToTarget();
        }
      } else {
        if (mDeleteFiles.size() > 1 || folderDeleted) {
          mParentHandler.obtainMessage(MESSAGE_DELETE_FINISHED, ARG_DELETE_MULTIPLE_FAILED, 0)
              .sendToTarget();
        } else {
          mParentHandler.obtainMessage(MESSAGE_DELETE_FINISHED, ARG_DELETE_FAILED, 0).sendToTarget();
        }
      }
    }
  }

  private boolean delete(File file) {
    boolean result = true;

    if (file.isDirectory()) {
      File[] list = file.listFiles();
      if (list != null) {
        for (File tempFile : list) {
          result = delete(tempFile) && result;
          // Now that we have deleted the file, if this is media file we need to
          // delete from Media store
          // new DeleteFileFromMediaStoreTask().execute(tempFile);
        }
      }
      if (result) {
        try {
          result = file.delete() && result;
          // Send Intent to media scanner to scan the folder
        } catch (Exception e) {
          e.printStackTrace();
          result = false;
        }
      }
    } else {
      try {
        result = file.delete();
      } catch (Exception e) {
        e.printStackTrace();
        result = false;
      }
      // scan the parent file of the folder just deleted
      File parentFile = file.getParentFile();
      if (parentFile != null) {
        mediaScanFolder(parentFile.getAbsoluteFile());
      }
    }

    return result;
  }

  // temporarily use to build success in eclipse
  // temp fix for porting. Remove comments later
  private static final String ACTION_MEDIA_SCANNER_SCAN_FOLDER =
      "com.internal.intent.action.MEDIA_SCANNER_SCAN_FOLDER";

  public void mediaScanFolder(File folder) {
    Intent intent = new Intent(ACTION_MEDIA_SCANNER_SCAN_FOLDER);
    Uri uri = Uri.fromFile(folder);
    intent.setData(uri);
    FileManagerApp.log(TAG + "mediaScanFolder " + folder.toString() + " " + intent.toString());
    try {
      this.sendBroadcast(intent);
    } catch (android.content.ActivityNotFoundException ex) {
      ex.printStackTrace();
    }
  }

  public void mediaScanFile(String newFileName) {
    // Scan the file , in case it is not in directory
    Intent myIntent =
        new Intent(android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse(newFileName));
    try {
      this.sendBroadcast(myIntent);
    } catch (android.content.ActivityNotFoundException ex) {
      ex.printStackTrace();
    }
    FileManagerApp.log(TAG + "mediaScanFile " + newFileName + " " + myIntent.toString());
  }

  @Override
  public boolean onKeyLongPress(int keyCode, KeyEvent event) {
    switch (keyCode) {
      case KeyEvent.KEYCODE_MENU :
        Log.d(TAG, "MENU long press");
        return true;
    }
    return super.onKeyLongPress(keyCode, event);
  }
}
