
package com.filemanager;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.MotoEnvironment;
import android.os.Handler;
import android.os.SystemProperties;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.motorola.filemanager.utils.IconifiedText;
import com.motorola.filemanager.utils.IconifiedTextListAdapter;

public class FileManager extends Activity {
  public final static String ACTION_RESTART_ACTIVITY = "com.mot.FileManagerIntents.ACTION_RESTART_ACTIVITY";
  public final static String ACTION_SELECTFILE = "com.mot.FileManagerIntents.ACTION_SELECTFILE";
  public final static String ACTION_SELECTFOLDER = "com.mot.FileManagerIntents.ACTION_SELECTFOLDER";
  // USB Host
  public final static String ACTION_USBDISKMOUNTED = "com.motorola.intent.action.USB_DISK_MOUNTED_NOTIFY";
  // USB Host End

  public final static String EXTRA_KEY_RESULT = "FILEPATH";
  public final static String EXTRA_KEY_AUTHINFO = "AUTHINFO";

  public final static String EXTRA_KEY_HOMESYNC_TITLE = "HOMESYNC_TITLE";
  public final static String EXTRA_KEY_HOMESYNC_STEP = "HOMESYNC_STEP";

  public static final String EXTRA_KEY_DISKNUMBER = "DISK_NUMBER";
  public static final String EXTRA_KEY_CURRENT_USBPATH = "CURRENT_USBPATH";
  private static final String EXTRA_KEY_DISK[] = new String[]{"DISK1", "DISK2", "DISK3"};

  public static final String EXTRA_KEY_CONTENT = "CURRENT_CONTENT";

  public static final String HIDEUNKOWNSETTING = "HideUnkownSetting";

  public static final String ID_LOCAL = "Local";
  public static final String ID_EXTSDCARD = "Extcard";
  public static final String ID_REMOTE = "Rmote";
  public static final String ID_MOTOCONNECT = "MC";
  public static final String ID_PROTECTED = "Protected"; // work around to track if protected content.
  public static final String ID_USB = "Usb"; // USB Host

  static private String mCurrentContent = ID_LOCAL;
  private static boolean eMMCEnabled = false;
  private static boolean mMassEnabled = false;
  private static boolean mEMMCPrimary= false;
  public static final int USB_DISK_1 = 1;
  public static final int USB_DISK_2 = 2;
  public static final int USB_DISK_3 = 3;
  static private Context mContext = null;
  static private Activity mInstance = null;
  private View mHomePage;
  private View mFileChooserPanel;
  private Button mFileChooserCancelButton;
  private int mSelectedUsbIndex = -1;
  private boolean mWiFiDialogDisplaying = false;

  private static final String TAG = "FileManager: ";
  static private final IntentFilter FM_Event_Filter = new IntentFilter(FileManager.ACTION_USBDISKMOUNTED);

  // private String TAG = "FileManager";
  private Handler mHighlightHandler = new Handler();
  // IKSTABLEFIVE-2633 - Start
  private List<IconifiedText> mHomePageStaticItems = new ArrayList<IconifiedText>();
  private List<IconifiedText> mHomePageCurrentList = new ArrayList<IconifiedText>();
  private AbsListView mHomePageListView;
  private IconifiedTextListAdapter mHomePageListAdapter = null;

  // IKSTABLEFIVE-2633 - End
  @Override
  protected void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    initVar(this, this);
    eMMCEnabled = (SystemProperties.getInt("ro.mot.internalsdcard", 0) != 0);
    mMassEnabled= getMassEnabled();
    FileManagerApp.log(TAG + "in onCreate()   mMassEnabled=" + mMassEnabled);
    mEMMCPrimary = isEMMCPrimary();
    FileManagerApp.log(TAG + "in onCreate()  mEMMCPrimary=" + mEMMCPrimary);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    setContentView(R.layout.file_manager);
    mHomePage = findViewById(R.id.home_page);
    mFileChooserPanel = findViewById(R.id.file_chooser_panel);
    mFileChooserCancelButton = (Button) findViewById(R.id.file_chooser_cancel);
    mFileChooserCancelButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        finish();
      }
    });

    initHomePage();
    showHomePage();

    IntentFilter iFilt = new IntentFilter();
    iFilt.addAction(FileManager.ACTION_USBDISKMOUNTED);
    registerReceiver(mBroadCaseReveiver, iFilt);
    FileManagerApp.setPasteMode(FileManagerApp.NO_PASTE);
  }

  private static void initVar(Context context, Activity instance) {
    mContext = context;
    mInstance = instance;
  }

  private void initHomePage() {
    // IKSTABLEFIVE-2633
    mHomePageListView = (AbsListView) findViewById(R.id.home_page_list);
    mHomePageListView.setVisibility(View.VISIBLE);
    mHomePageListView.setTextFilterEnabled(true);
    mHomePageListView.requestFocus();
    mHomePageListView.requestFocusFromTouch();

    mHomePageListAdapter = new IconifiedTextListAdapter(this);
    mHomePageListAdapter.setListItems(mHomePageCurrentList, mHomePageListView.hasTextFilter());
    mHomePageListView.setAdapter(mHomePageListAdapter);

    mHomePageStaticItems.clear();
    mHomePageCurrentList.clear();

     if ((mMassEnabled) && (mEMMCPrimary)){
       IconifiedText internalmemory =
         new IconifiedText(getString(R.string.internal_storage_primary),
                           getResources().getDrawable(R.drawable.ic_thb_device));
       internalmemory.setIsNormalFile(false);
       mHomePageStaticItems.add(internalmemory);
     }
     else if ((mMassEnabled) && ( !mEMMCPrimary)){
       IconifiedText internalmemory =
         new IconifiedText(getString(R.string.internal_storage),
                           getResources().getDrawable(R.drawable.ic_thb_device));
       internalmemory.setIsNormalFile(false);
       mHomePageStaticItems.add(internalmemory);
     }else if ((!mMassEnabled) && (eMMCEnabled) ){
        IconifiedText internalmemory = new IconifiedText(getString(R.string.internal_phone_storage),getResources().getDrawable(R.drawable.ic_thb_device));
        internalmemory.setIsNormalFile(false);
        mHomePageStaticItems.add(internalmemory);
     }
     if ((mMassEnabled) && (!mEMMCPrimary)){
       IconifiedText sdcard =
         new IconifiedText(getString(R.string.sd_card_primary),
                           getResources().getDrawable(R.drawable.ic_thb_external_sdcard));
       sdcard.setIsNormalFile(false);
       mHomePageStaticItems.add(sdcard);
     }
     else{
       IconifiedText sdcard =
         new IconifiedText(getString(R.string.sd_card),
                           getResources().getDrawable(R.drawable.ic_thb_external_sdcard));
       sdcard.setIsNormalFile(false);
       mHomePageStaticItems.add(sdcard);
     }

    IconifiedText shared_files =
        new IconifiedText(getString(R.string.remote_files),
                          getResources().getDrawable(R.drawable.ic_thb_shared_folder));
    shared_files.setIsNormalFile(false);
    mHomePageStaticItems.add(shared_files);

    IconifiedText shared_comps =
        new IconifiedText(getString(R.string.remote_computers),
                          getResources().getDrawable(R.drawable.ic_thb_moto_connect));
    shared_comps.setIsNormalFile(false);
    mHomePageStaticItems.add(shared_comps);

    Intent intent = getIntent();
    String intentAction = intent.getAction();
    if (intentAction != null) {
      if (intentAction.equals(ACTION_SELECTFILE)) {
        FileManagerApp.setIsGridView(false);
        FileManagerApp.setLaunchMode(FileManagerApp.SELECT_FILE_MODE);
        String extraTitle = intent.getStringExtra(EXTRA_KEY_HOMESYNC_TITLE);
        String extraStep = intent.getStringExtra(EXTRA_KEY_HOMESYNC_STEP);
        if (extraTitle == null) {
          mFileChooserPanel.setVisibility(View.VISIBLE);
          findViewById(R.id.homesync_bar).setVisibility(View.GONE);
          FileManagerApp.setShowFolderViewIcon(true);
        } else {
          mFileChooserPanel.setVisibility(View.GONE);
          findViewById(R.id.homesync_bar).setVisibility(View.VISIBLE);
          ((TextView) findViewById(R.id.homesync_title)).setText(extraTitle);
          ((TextView) findViewById(R.id.homesync_step)).setText(extraStep);
          FileManagerApp.setShowFolderViewIcon(false);
          if (isAttDrmContentAvailable()) {
            IconifiedText protectedcontent =
                new IconifiedText(getString(R.string.protected_content), getResources()
                    .getDrawable(R.drawable.ic_launcher_folder_protected_content));
            protectedcontent.setIsNormalFile(false);
            mHomePageStaticItems.add(protectedcontent);
          }
        }
      } else if (intentAction.equals(ACTION_SELECTFOLDER)) {
        FileManagerApp.setIsGridView(false);
        FileManagerApp.setLaunchMode(FileManagerApp.SELECT_FOLDER_MODE);
        String extraTitle = intent.getStringExtra(EXTRA_KEY_HOMESYNC_TITLE);
        String extraStep = intent.getStringExtra(EXTRA_KEY_HOMESYNC_STEP);
        if (extraTitle == null) {
          mFileChooserPanel.setVisibility(View.VISIBLE);
          findViewById(R.id.homesync_bar).setVisibility(View.GONE);
          FileManagerApp.setShowFolderViewIcon(true);
        } else {
          mFileChooserPanel.setVisibility(View.GONE);
          findViewById(R.id.homesync_bar).setVisibility(View.VISIBLE);
          ((TextView) findViewById(R.id.homesync_title)).setText(extraTitle);
          ((TextView) findViewById(R.id.homesync_step)).setText(extraStep);
          FileManagerApp.setShowFolderViewIcon(false);
          if (isAttDrmContentAvailable()) {
            IconifiedText protectedcontent =
                new IconifiedText(getString(R.string.protected_content), getResources()
                    .getDrawable(R.drawable.ic_launcher_folder_protected_content));
            protectedcontent.setIsNormalFile(false);
            mHomePageStaticItems.add(protectedcontent);
          }
        }
      } else if (intentAction.equals(Intent.ACTION_GET_CONTENT)) {
        // Disable MotoConnect for service mode as not specified in requirement.
        mHomePageStaticItems.remove(shared_comps);
        FileManagerApp.log(TAG + "intent is " + intent.getExtras());
        FileManagerApp.setLaunchMode(FileManagerApp.SELECT_GET_CONTENT);
        ((FileManagerApp) getApplication()).saveContentIntent(intent);
        ((FileManagerApp) getApplication()).saveCallingPackageName(getCallingPackage());
      } else {
        ((FileManagerApp) getApplication()).resetGridViewMode();
        FileManagerApp.setLaunchMode(FileManagerApp.NORMAL_MODE);
        if (isAttDrmContentAvailable()) {
          IconifiedText protectedcontent =
              new IconifiedText(getString(R.string.protected_content), getResources().getDrawable(
                  R.drawable.ic_launcher_folder_protected_content));
          protectedcontent.setIsNormalFile(false);
          mHomePageStaticItems.add(protectedcontent);
        }
        mFileChooserPanel.setVisibility(View.GONE);
        FileManagerApp.setShowFolderViewIcon(true);
      }
    }

    // Add the static items to current list before checking for the dynamic
    // elements
    addAllElements(mHomePageCurrentList, mHomePageStaticItems);

    // USB host
    // Receive USB sticky intent
    Intent usbIntent = registerReceiver(null, FM_Event_Filter);
    if (usbIntent == null) {
      FileManagerApp.log(TAG + "There's no sticky USB intent now");
      // No need to add USB Drive menus
    } else {
      FileManagerApp.log(TAG + "Received USB mount sticky intent in onCreate()");
      handleUsbNotifyIntent(usbIntent);
    } // USB Host end

    mHomePageListView.setOnItemClickListener(homePageListListener);
    mHomePageListAdapter.notifyDataSetChanged();
  }

  AdapterView.OnItemClickListener homePageListListener = new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
      IconifiedTextListAdapter adapter = (IconifiedTextListAdapter) parent.getAdapter();
      if (adapter == null) {
        return;
      }

      IconifiedText text = (IconifiedText) adapter.getItem(position);
      String file = text.getText();

         if (file.equals(getString(R.string.internal_phone_storage))||
           file.equals(getString(R.string.internal_storage_primary))){     
           if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            if (!isFinishing()) {
              (new AlertDialog.Builder(mContext)).setTitle(R.string.internal_phone_storage)
                .setMessage(R.string.internal_phone_storage_unmounted)
                .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialog, int which) {
                  }
                }).create().show();
            }
        } else {
          mCurrentContent = ID_LOCAL;
          // showContentPage need to be called outside onClick to show
          // highlighted item.
          mHighlightHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
              showContentPage();
            }
          }, 100);
        }

      }else if (file.equals(getString(R.string.internal_storage))) {
         if (!MotoEnvironment.getExternalAltStorageState().equalsIgnoreCase(Environment.MEDIA_MOUNTED)){
            if (!isFinishing()) {
            (new AlertDialog.Builder(mContext)).setTitle(R.string.internal_storage)
                .setMessage(R.string.internal_phone_storage_unmounted)
                .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialog, int which) {
                  }
                }).create().show();
          }
        }
        else{
          mCurrentContent = ID_EXTSDCARD;
          // showContentPage need to be called outside onClick to show
          // highlighted item.
          mHighlightHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
              showContentPage();
            }
          }, 100);
        }
      }else if (file.equals(getString(R.string.sd_card))||file.equals(getString(R.string.sd_card_primary))) {
        try {
          // if
          // (!MotoEnvironment.getExternalAltStorageState().equalsIgnoreCase(Environment.MEDIA_MOUNTED))
          // {
          // (new AlertDialog.Builder(mContext))
          // .setTitle(R.string.sd_card)
          // .setMessage(R.string.sd_missing)
          // .setNeutralButton(R.string.ok, new
          // DialogInterface.OnClickListener() {
          // public void onClick(DialogInterface dialog, int which){
          // }
          // })
          // .create().show();
          // } else {

          if ( mMassEnabled ){
            if ((!mEMMCPrimary)){
              mCurrentContent = ID_LOCAL;
            }
            else{
               mCurrentContent = ID_EXTSDCARD;
            }
          }
          else{
            if (getEMMCEnabled()) {
              mCurrentContent = ID_EXTSDCARD;
            } else {
              mCurrentContent = ID_LOCAL;
            }
          }
          // showContentPage need to be called outside onClick to show
          // highlighted item.
          mHighlightHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
              showContentPage();
            }
          }, 100);
          // }
        } catch (NoClassDefFoundError e) {
          Toast.makeText(mContext, "NoClassDefFoundError", Toast.LENGTH_SHORT).show();
        }
      } else if (file.equals(getString(R.string.remote_files))) {
        if (!checkConnAvailable()) {
          if (!mWiFiDialogDisplaying) {
            if (!isFinishing()) {
              mWiFiDialogDisplaying = true;
              (new AlertDialog.Builder(mContext)).setIcon(android.R.drawable.ic_dialog_alert)
                  .setTitle(R.string.wifi).setMessage(R.string.wifi_unavaiable)
                  .setPositiveButton(R.string.open_wifi, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                      Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                      mContext.startActivity(intent);
                      mWiFiDialogDisplaying = false;
                    }
                  }).setNegativeButton(R.string.cancle, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                      mWiFiDialogDisplaying = false;
                    }
                  }).setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                      if (event.getAction() == KeyEvent.ACTION_DOWN) {
                        switch (keyCode) {
                          case KeyEvent.KEYCODE_BACK :
                            mWiFiDialogDisplaying = false;
                        }
                      }
                      return false;
                    }
                  }).create().show();
            }
          }
        } else {
          mCurrentContent = ID_REMOTE;
          // showContentPage need to be called outside onClick to show
          // highlighted item.
          mHighlightHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
              showContentPage();
            }
          }, 100);
        }
      } else if (file.equals(getString(R.string.remote_computers))) {
        mCurrentContent = ID_MOTOCONNECT;
        showContentPage();
      } else if (file.equals(getString(R.string.protected_content))) {
        // Check If AT&T DRM intent is there (IKSTABLEFOUR-1454)
        if (isAttDrmContentAvailable()) {
          // Start protected content app
          try {
            Intent intent = new Intent("com.motorola.AttDrmContent.LAUNCH");
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            final ComponentName cn =
                new ComponentName("com.motorola.AttDrmContent",
                    "com.motorola.AttDrmContent.AttDrmContent");
            intent.setComponent(cn);
            //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // IKSTABLE6-3112, vjth74
            startActivity(intent);
            mCurrentContent = ID_PROTECTED;
          } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            if (!isFinishing()) {
              (new AlertDialog.Builder(mContext)).setTitle(R.string.protected_content)
                  .setMessage(R.string.protected_content_fail)
                  .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                  }).create().show();
            }
          }
        }
      } else if (file.equals(getString(R.string.usb_files))) {
        // USB Host
        if (!isUsbDiskConnected()) {
          if (!isFinishing()) {
            (new AlertDialog.Builder(mContext)).setTitle(R.string.usbdisk)
                .setMessage(R.string.usbdisk_missing)
                .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                  @Override
                  public void onClick(DialogInterface dialog, int which) {
                  }
                }).create().show();
          }
        } else {
          mCurrentContent = ID_USB;
          mSelectedUsbIndex = position - mHomePageStaticItems.size();
          // showContentPage need to be called outside onClick to show
          // highlighted item.
          mHighlightHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
              showContentPage();
            }
          }, 100);
        }
        // USB Host end
      }
    }
  };

  private void addAllElements(List<IconifiedText> addTo, List<IconifiedText> addFrom) {
    int size = addFrom.size();
    for (int i = 0; i < size; i++) {
      addTo.add(addFrom.get(i));
    }
  }
  // IKSTABLEFIVE-2633 - End

  private BroadcastReceiver mBroadCaseReveiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
      String intentAction = intent.getAction();
      if (intentAction == null) {
        // Intent is null, no action needed
        FileManagerApp.log(TAG + "Received a null Intent in BroadcastReceiver");
      } else if (intentAction.equals(FileManager.ACTION_USBDISKMOUNTED)) {
        FileManagerApp.log(TAG + "Received USB mount intent in BroadcastReceiver()");
        handleUsbNotifyIntent(intent);
      }
    }
  };

  @Override
  public void onDestroy() {
    unregisterReceiver(mBroadCaseReveiver);
    // IKSTABLEFIVE-2633 - Start
    mHomePageCurrentList.clear();
    mHomePageStaticItems.clear();
    mHomePageListView.setAdapter(null);
    // IKSTABLEFIVE-2633 - End
    super.onDestroy();
  }

  private void showHomePage() {
    mHomePage.setVisibility(View.VISIBLE);
    FileManagerApp.setPhoneStoragePath(0, -1);

    TextView homePageTitle = (TextView) findViewById(R.id.home_page_title);
    if (FileManagerApp.getLaunchMode() == FileManagerApp.SELECT_FILE_MODE) {
      homePageTitle.setText(R.string.select_file);
    } else if (FileManagerApp.getLaunchMode() == FileManagerApp.SELECT_FOLDER_MODE) {
      homePageTitle.setText(R.string.select_folder);
    }
  }

  private void showContentPage() {
    if (mCurrentContent.equals(ID_LOCAL)) {
      FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_SDCARD, -1);
    } else if (mCurrentContent.equals(ID_EXTSDCARD)) {
      FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_ALT_SDCARD, -1);
    } else if (mCurrentContent.equals(ID_USB)) {
      FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_USB_DISK,
          mSelectedUsbIndex);
    } else if (mCurrentContent.equals(ID_MOTOCONNECT)) {
      // Need to check this
      // FileManagerApp.setPhoneStoragePath(FileManagerApp.STORAGE_MODE_EXTENAL_ALT_SDCARD,
      // -1);
    }

    Intent intent = new Intent(this, FileManagerContent.class);
    intent.setAction(FileManager.ACTION_RESTART_ACTIVITY);
    intent.putExtra(FileManager.EXTRA_KEY_CONTENT, mCurrentContent);
    if (FileManagerApp.getLaunchMode() == FileManagerApp.SELECT_FILE_MODE ||
        FileManagerApp.getLaunchMode() == FileManagerApp.SELECT_FOLDER_MODE) {
      intent.putExtra(FileManager.EXTRA_KEY_HOMESYNC_TITLE,
          ((TextView) findViewById(R.id.homesync_title)).getText());
      intent.putExtra(FileManager.EXTRA_KEY_HOMESYNC_STEP,
          ((TextView) findViewById(R.id.homesync_step)).getText());
    }
    startActivity(intent);
  }

  public static String getCurrentContent() {
    return mCurrentContent;
  }

  @Override
  protected void onNewIntent(Intent intent) {
    // no action needed, not expecting any new intents
    FileManagerApp.log(TAG + "Received a Intent in onNewIntent");
  }

  public static void rtnPickerResult(String filePath, String authInfo) {
    Intent returnIntent = new Intent();
    returnIntent.putExtra(FileManager.EXTRA_KEY_RESULT, filePath);
    if (authInfo != null) {
      returnIntent.putExtra(FileManager.EXTRA_KEY_AUTHINFO, authInfo);
    }
    rtnPickerResult(returnIntent);
  }

  public static void rtnPickerResult(Intent iData) {
    FileManagerApp.setLaunchMode(FileManagerApp.NORMAL_MODE);

    if (mInstance != null) {
      mInstance.setResult(RESULT_OK, iData);
      mInstance.finish();
    }
    if (FileManagerContent.getActivityGroup() != null) {
      (FileManagerContent.getActivityGroup()).finish();
    }
  }

  static public Context getCurContext() {
    return mContext;
  }

  private boolean checkConnAvailable() {
    ConnectivityManager cm =
        (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo networkInfo = null;
    if (cm == null) {
      return false;
    }
    networkInfo = cm.getActiveNetworkInfo();
    if (networkInfo == null || networkInfo.getType() != ConnectivityManager.TYPE_WIFI ||
        !networkInfo.isConnected()) {
      return false;
    }
    return true;
  }

  // USB Host
  // Get connected USB disk num and path
  private boolean isUsbDiskConnected() {
    return FileManagerApp.isUsbDiskConnected();
  }

  private void synUsbConnectedInfo(Bundle bundle) {
    FileManagerApp.setUsbDiskConnected(false);
    FileManagerApp.setUsbDisknum(bundle.getInt(FileManager.EXTRA_KEY_DISKNUMBER, 0));
    FileManagerApp.log(TAG + "USB disknum is " + FileManagerApp.getUsbDisknum());
    FileManagerApp.setUsbDiskConnected(FileManagerApp.getUsbDisknum() > 0 ? true : false);

    for (int i = 0; i < FileManagerApp.MAX_USB_DISK_NUM; i++) {
      FileManagerApp.setUsbDiskPath("", i);
      if (i < FileManagerApp.getUsbDisknum()) {
        FileManagerApp.setUsbDiskPath(bundle.getString(FileManager.EXTRA_KEY_DISK[i]), i);
        FileManagerApp.log(TAG + i + "th usbdisk path is " + FileManagerApp.getUsbDiskPath(i));
      }
    }
  }

  private void handleUsbNotifyIntent(Intent usbIntent) {
    Bundle bundle = usbIntent.getExtras();
    if (bundle != null) {
      synUsbConnectedInfo(bundle);
      // IKSTABLEFIVE-2633 - Start
      mHomePageCurrentList.clear();
      addAllElements(mHomePageCurrentList, mHomePageStaticItems);
      IconifiedText usb =
          new IconifiedText(getString(R.string.usb_files), getResources().getDrawable(
              R.drawable.ic_thb_usb_disk));
      usb.setIsNormalFile(false);
      if (FileManagerApp.getUsbDisknum() == USB_DISK_1) {
        mHomePageCurrentList.add(usb);
      } else if (FileManagerApp.getUsbDisknum() == USB_DISK_2) {
        mHomePageCurrentList.add(usb);
        mHomePageCurrentList.add(usb);
      } else if (FileManagerApp.getUsbDisknum() == USB_DISK_3) {
        mHomePageCurrentList.add(usb);
        mHomePageCurrentList.add(usb);
        mHomePageCurrentList.add(usb);
      } else {
        // No USB Disk, don't add any to Home Page Current List
      }
      mHomePageListAdapter.notifyDataSetChanged();
      // IKSTABLEFIVE-2633 - End
    } else {
      FileManagerApp.log(TAG + "bundle is null, it's an invalid USB update intent");
    }
  }

  // USB Host end

  // Check If AT&T DRM intent is there (IKSTABLEFOUR-1454)
  public boolean isAttDrmContentAvailable() {
    boolean isAttDrmContent = true;
    PackageManager pm = getPackageManager();
    try {
      ApplicationInfo appInfo = pm.getApplicationInfo("com.motorola.AttDrmContent", 0);
      if (appInfo != null) {
        Log.d(TAG, "App info" + appInfo.name);
      }
      // if we get to here this mean the app is there and the flag will remain
      // true.
    } catch (NameNotFoundException e) {
      // app was not found
      isAttDrmContent = false;
      Log.d(TAG, " can't find AttDrmContent");
    }
    return isAttDrmContent;
  }

  @Override
  public boolean onKeyLongPress(int keyCode, KeyEvent event) {
    switch (keyCode) {
      case KeyEvent.KEYCODE_MENU :
        Log.d(TAG, "MENU long press");
        return true;
    }
    return super.onKeyLongPress(keyCode, event);
  }

   public static boolean getEMMCEnabled()
   {
       eMMCEnabled= (SystemProperties.getInt("ro.mot.internalsdcard", 0) != 0);
       FileManagerApp.log(TAG + "in getEMMCEnabled() ro.mot.internalsdcard=" + SystemProperties.getInt("ro.mot.internalsdcard", 0));
       return eMMCEnabled;
   }
   public static boolean getMassEnabled()
   {
       //Debug purpose. Comment it out now
       //FileManagerApp.log(TAG + "in getMassEnabled() retun value ="+(SystemProperties.getInt("ro.mot.internalsdcard", 0) == 2));
       return (SystemProperties.getInt("ro.mot.internalsdcard", 0) == 2);
   }
   public static boolean isEMMCPrimary()
   {
       //Debug purpose. Comment it out now
       //FileManagerApp.log(TAG + "in isEMMCPrimary()  "retun value =" +  (!Environment.isExternalStorageRemovable());
       return (!Environment.isExternalStorageRemovable());
   }

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode ==KeyEvent.KEYCODE_MENU){
      if (event!=null){
        if (event.getRepeatCount() >0){
          return true;
        }
      }
    }
    return super.onKeyDown(keyCode, event);
  }
}
