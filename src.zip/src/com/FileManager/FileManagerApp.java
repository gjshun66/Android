
package com.filemanager;

import java.io.File;
import java.util.ArrayList;

import android.app.Application;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;



public class FileManagerApp extends Application {
  public static final int NORMAL_MODE = 250;
  public static final int SELECT_FILE_MODE = 251;
  public static final int SELECT_FOLDER_MODE = 252;
  public static final int SELECT_GET_CONTENT = 253;

  private static int mLaunchMode = NORMAL_MODE;

  private static String TAG = "FileManagerApp";
  public static final boolean DBG = true;

  public final static String ROOT = "/";
  public final static String ROOT_DIR = "/mnt";
  public final static String SD_CARD_DIR = ROOT_DIR + "/sdcard";
  public final static String SD_CARD_EXT_DIR = ROOT_DIR + "/sdcard-ext";
  public final static String SD_CARD_SECONDARY_DIR = ROOT_DIR + "/sdcard2";

  public static final int MAX_USB_DISK_NUM = 3;
  private static boolean mUsbDiskConnected = false;
  private static int mUsbDiskNum = 0;
  private static String mUsbDiskListPath[] = new String[MAX_USB_DISK_NUM];
  public String mCurrentUsbPath;

  public static final int NO_PASTE = 350;
  public static final int MOVE_MODE = 351;
  public static final int COPY_MODE = 352;
  private static int mPasteMode = NO_PASTE;
  private static ArrayList<String> mPasteFiles;
  private static boolean mIsGridView = false;
  private static boolean mShowFolderViewIcon = true;
  private static final String SETTINGS = "settings";
  private static final String VIEWMODE = "view mode";
  private static final String SORTMODE = "sort mode";
  private static final String SEARCHOPTION = "search option";
  public static final int NAMESORT = 300;
  public static final int TYPESORT = 301;
  public static final int TIMESORT = 302;
  public static final int SIZESORT = 303;
  private static int mSortMode = NAMESORT;

  public static final int INTERNALSTORAGE = 0;
  public static final int SDCARD = 1;
  private static int mSearchOption = INTERNALSTORAGE;

  private static String mStoragePath;
  private Intent mContentIntent;
  private String mCallingPackageName = null;

  public static final int STORAGE_MODE_EXTENAL_SDCARD = 1;
  public static final int STORAGE_MODE_EXTENAL_ALT_SDCARD = 2;
  public static final int STORAGE_MODE_EXTENAL_USB_DISK = 3;

  private static int mStorgeMediumMode = 0;

  public static void setLaunchMode(int launchMode) {
    mLaunchMode = launchMode;
  }

  public static int getLaunchMode() {
    return mLaunchMode;
  }

  public static void setPasteMode(int inPasteMode) {
    mPasteMode = inPasteMode;
  }

  public static int getPasteMode() {
    return mPasteMode;
  }

  public static void setPasteFiles(ArrayList<String> files) {
    mPasteFiles = files;
  }

  public static ArrayList<String> getPasteFiles() {
    return mPasteFiles;
  }

  public static void setIsGridView(boolean isGridView) {
    mIsGridView = isGridView;
  }

  public void setGridView(boolean isGridView) {
    setIsGridView(isGridView);
    SharedPreferences viewSetting = getSharedPreferences(SETTINGS, 0);
    SharedPreferences.Editor editor = viewSetting.edit();
    editor.putBoolean(VIEWMODE, mIsGridView);
    editor.commit();
  }

  public void resetGridViewMode() {
    SharedPreferences setting = getSharedPreferences(SETTINGS, 0);
    boolean isGridView = setting.getBoolean(VIEWMODE, false);
    setIsGridView(isGridView);
    int sortMode = setting.getInt(SORTMODE, NAMESORT);
    setSortMode(sortMode);
  }

  public static boolean isGridView() {
    return mIsGridView;
  }

  public static void setmSortMode(int sortmode) {
    mSortMode = sortmode;
  }

  public void setSortMode(int sortmode) {
    setmSortMode(sortmode);
    SharedPreferences setting = getSharedPreferences(SETTINGS, 0);
    SharedPreferences.Editor editor = setting.edit();
    editor.putInt(SORTMODE, mSortMode);
    editor.commit();
  }

  public static int getSortMode() {
    return mSortMode;
  }

  public static void setmSearchOption(int searchOption) {
    mSearchOption = searchOption;
  }

  public void setSearchOption(int searchOption) {
    log("Set search option to" + searchOption);
    setmSearchOption(searchOption);
    SharedPreferences setting = getSharedPreferences(SETTINGS, 0);
    SharedPreferences.Editor editor = setting.edit();
    editor.putInt(SEARCHOPTION, mSearchOption);
    editor.commit();
  }

  public static int getSearchOption() {
    return mSearchOption;
  }

  public static boolean isShowFolderViewIcon() {
    return mShowFolderViewIcon;
  }

  public static void setShowFolderViewIcon(boolean show) {
    mShowFolderViewIcon = show;
  }

  public FileManagerApp() {
    super();
  }

  @Override
  public void onCreate() {
    super.onCreate();
    startDownloadServer();

    SharedPreferences setting = getSharedPreferences(SETTINGS, 0);
    boolean isGridView = setting.getBoolean(VIEWMODE, false);
    setIsGridView(isGridView);
    int sortMode = setting.getInt(SORTMODE, NAMESORT);
    setmSortMode(sortMode);
  }

  private void stopDownloadServer() {
    log("stopService SambaDownloadServer");
    stopService(new Intent(this, DownloadServer.class));
  }

  private void startDownloadServer() {
    Bundle args = new Bundle();
    log("startService SambaDownloadServer");
    args.putInt(DownloadServer.DOWNLOAD_MODE, DownloadServer.SAMBA_DOWNLOAD);
    startService(new Intent(this, DownloadServer.class).putExtras(args));
  }

 
 

  @Override
  public void onTerminate() {
    super.onTerminate();
    stopDownloadServer();
   
    SambaTransferHandler.setUserAuth(null);
  }

  private static String getStoreLocationPath(int cardId, int offset) {
    String path = null;
    switch (cardId) {
      case STORAGE_MODE_EXTENAL_SDCARD : // ID_EXTSDCARD
        try {
          File file = Environment.getExternalStorageDirectory();
          if (file != null) {
            path = file.getAbsolutePath();
          }
        } catch (Exception e) {
           e.printStackTrace();
        }
        break;
      case STORAGE_MODE_EXTENAL_ALT_SDCARD : // ID_LOCAL
        try {
          File file = Environment.getExternalAltStorageDirectory();
          if (file != null) {
            path = file.getAbsolutePath();
          }
        } catch (Exception e) {
           e.printStackTrace();
        }
        break;
      case STORAGE_MODE_EXTENAL_USB_DISK : // ID_USB
        path = mUsbDiskListPath[offset];
      default :
        break;
    }
    return path;
  }

  public static String getPhoneStoragePath() {
    log("Get mStoragePath " + mStoragePath);
    return mStoragePath;
  }

  public static void setPhoneStoragePath(String path) {
    mStoragePath = path;
  }

  public static void setPhoneStoragePath(int cardId, int offset) {
    setStorageMediumMode(cardId);
    mStoragePath = getStoreLocationPath(cardId, offset);
    log("Set mStoragePath to " + mStoragePath);
  }

  private static void setStorageMediumMode(final int mode) {
    mStorgeMediumMode = mode;
  }

  public static int getStorageMediumMode() {
    return mStorgeMediumMode;
  }

  public void saveContentIntent(Intent cIntent) {
    mContentIntent = cIntent;
  }

  public Intent getContentIntent() {
    return mContentIntent;
  }


  public void saveCallingPackageName(String CallingPackageName) {
    mCallingPackageName = CallingPackageName;
  }

  public String getCallingPackageName() {
    return mCallingPackageName;
  }

  public static void log(String info) {
    if (FileManagerApp.DBG) {
      Log.w(TAG, info);
    }
  }

  public static String getUsbDiskPath(int i) {
    return mUsbDiskListPath[i];
  }

  public static void setUsbDiskPath(String usbDiskPath, int i) {
    mUsbDiskListPath[i] = usbDiskPath;
  }

  public static boolean isUsbDiskConnected() {
    return mUsbDiskConnected;
  }

  public static void setUsbDiskConnected(boolean usbDiskConnected) {
    mUsbDiskConnected = usbDiskConnected;
  }

  public static int getUsbDisknum() {
    return mUsbDiskNum;
  }

  public static void setUsbDisknum(int usbDisknum) {
    mUsbDiskNum = usbDisknum;
  }
  private MCServiceConnection mService = new MCServiceConnection();
  private int mRegistrations = 0;
  private boolean mClientStartedBeforeConnect = false;
  /**
   * Observer class for receiving callbacks when the service is started and connected.
   *
   */
  public interface RegisterObserver {
    /**
     * Callback for receiving the result of starting/connecting to the MC service.
     * @param success True if successful, otherwise false.
     */
    public void onRegister(boolean success);
  }

  /**
   * Activities must register to start and connect the MC service.
   * Once the MC service has been started and connected the observer will be notified.
   * If the MC service is all ready connected then the observer will be notified immediately.
   *
   * @param observer The RegisterObserver to be notified with connection result.
   */
  public void register(final RegisterObserver observer) {
    if (!mService.serviceConnected()) {
      try {
        mService.connectService(this, new MCServiceObserver() {

          @Override
          public void onServiceDisconnected() {
          }

          @Override
          public void onServiceConnected(boolean success) {
            if (success && mClientStartedBeforeConnect) {
              clientStarted();
              mClientStartedBeforeConnect = false;
            }
            if (observer != null) {
              observer.onRegister(success);
            }
            onMCServiceConnected(success);
          }
        });
      } catch (MCException e) {
        Log.e(TAG, "MC service unavailable");
      }
    } else {
      if (observer != null) {
        observer.onRegister(true);
      }
      onMCServiceConnected(true);
    }
    mRegistrations++;
    log("register() mRegistrations = " + mRegistrations);
  }

  /**
   * Activities must unregister when they no longer need the MC service.
   * If all activities have unregistered then the MC service will be disconnected.
   */
  public void unregister() {
    mRegistrations--;
    log("unregister() mRegistrations = " + mRegistrations);
    if (mRegistrations <= 0) {
      mRegistrations = 0;
      if (mService.serviceConnected()) {
        log("unregister() disconnecting MC Service");
        mService.disconnectService();
      }
    }
  }

  /**
   * Activities that have registered should call the clientStarted in their onStart
   * method. This ensures that the MC service starts/maintains background connections.
   */
  public void clientStarted() {
    if (mService.serviceConnected()) {
      mService.clientStarted();
    } else {
      mClientStartedBeforeConnect = true;
    }
  }

  /**
   * Activities that have registered should call the clientStopped in their onStop
   * method. This allows the MC service to stop/disconnect background connections.
   */
  public void clientStopped() {
    if (mService.serviceConnected()) {
      mService.clientStopped();
    }
  }

  /**
   * Get the MC service connection.
   * @return The MC service connection object.
   */
  public MCServiceConnection getMCService() {
    return mService;
  }

  protected void onMCServiceConnected(boolean success) {
    Log.i(TAG, "MCService connected");
    // Need to review later when switch to use download queue service.
    /*
     * mService.setupTransferQueue(getQueueName(), "DEFAULT",
     * PendingIntent.getActivity(this, 0, new
     * Intent(this,TransferManagerActivity.class),
     * PendingIntent.FLAG_UPDATE_CURRENT), false);
     */
  }

  public String getQueueName() {
    return getResources().getString(R.string.app_name);
  }

}
